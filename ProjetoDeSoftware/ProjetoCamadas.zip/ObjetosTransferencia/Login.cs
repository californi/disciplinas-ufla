﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetosTransferencia
{
    public class Login
    {
        public Usuario UsuarioLogado { get; set; }

        public bool RealizarLogin(string nome, string senha)
        {
            string strConsulta = "select id, nome, dataNascimento from usuario where nome = " + nome + "  and senha = " + senha;
            this.executarSQL(strConsulta);

            return UsuarioLogado != null;
        }

        private string executarSQL(string sql)
        {
            return string.Empty;
        }
    }
}
