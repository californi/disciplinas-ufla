﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetosTransferencia
{
    public class Usuario
    {
        public string? Id { get; set; }
        public string? Name { get; set; }

        public void cadastrar() { }
    }
}
