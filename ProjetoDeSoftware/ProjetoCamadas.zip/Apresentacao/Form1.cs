

namespace Apresentacao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ObjetosTransferencia.Usuario usuario = new ObjetosTransferencia.Usuario();
            Negocios.ValidacaoUsuario validacaoUsuario = new Negocios.ValidacaoUsuario();
            validacaoUsuario.ValidarLogin(usuario);
        }

    }
}
