﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace AcessoADados
{
    public class Consultas
    {

        public System.Data.DataTable RealizarConsulta(string query, string TypeQuery) { 
            // return resultSet; resultData
            DataTable dt = new DataTable();
            return dt;
        }

    }
}
