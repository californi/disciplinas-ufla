﻿using ObjetosTransferencia;
using AcessoADados;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Negocios
{
    public class ValidacaoUsuario
    {
        public void ValidarLogin(Usuario usuario) {

            AcessoADados.Consultas objConsultas = new AcessoADados.Consultas();
            System.Data.DataTable myDataTable = objConsultas.RealizarConsulta("spConsultarDados", "storedProcedure");
            List<Usuario> meusUsuarios = loadUsuarios(myDataTable);
            foreach (var item in meusUsuarios) {
                if (item.Name == "Lucas") { 
                
                }
            }

            
            Consultas objConsultas2 = new Consultas();
            objConsultas2.RealizarConsulta("spConsultarOutrosDados", "storedProcedure");
        }

        private List<Usuario> loadUsuarios(System.Data.DataTable dt) {
            List<Usuario> minhaLista = new List<Usuario>();
            foreach (DataRow item in dt.Rows)
            {
                Usuario novoUsuario = new Usuario();
                novoUsuario.Name = item == null ? "Usuario vazio" : item["id_usuario"].ToString();
                minhaLista.Add(novoUsuario);
            }
            return minhaLista;
        }
    }
}
